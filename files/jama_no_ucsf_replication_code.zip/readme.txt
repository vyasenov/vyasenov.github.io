Vasil Yasenov
11/11/2020

Replication Code for Yasenov et al. "Association between Health Care Utilization and Immigration Enforcement Events in San Francisco" published in JAMA Network Open on 11/10/2020

This folder contains the code used to produce the results in the additional Appendix.

Please address all inquiries to yasenov@gmail.com.

Thank you!

Notes:

************* DATA CREATE *************


data_build.do - takes raw SFHN data, cleans it and saves "final.dta", "final_kids.dta" and "final_male.dta" which are week-group level datasets.

events.do - creates "events.dta" which contains data on the six events in our analysis.



************* FIGURES *************


figures_trends.do - replicates Figures A2-A5 in the additional Appendix.

figures_diffindiff.do - replicates Figures A6-A8 in additional Appendix.

sample_composition.do - replicates Figure A9 in the additional Appendix using the raw SFHN data.



************* TABLES *************


sum_stats.do - replicates Table A1 in the additional Appendix.


regressions.do - replicates Table A2 in the additional Appendix. This table contains the resulted presented in Figure A6.


regressions_kids.do - replicates Table A3 in the additional Appendix. This table contains the resulted presented in Figure A7.


regressions_acs.do - replicates Table A4 in the additional Appendix. This table contains the resulted presented in Figure A8.


regressions_male.do - replicates Table A5 in the additional Appendix.